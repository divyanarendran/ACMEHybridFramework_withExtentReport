package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class VendorsSearchPage extends ProjectSpecificMethods {
public VendorsSearchPage(RemoteWebDriver driver, ExtentTest node, ExtentTest test){
	this.driver = driver;
	this.node = node;
	this.test = test;
	PageFactory.initElements(driver, this);
}	 
@FindBy(how=How.ID,using="vendorName")
 private WebElement eleVendorName;

public VendorsSearchPage enterVendorName() {
	clearAndType(eleVendorName, "Blue Lagoon");
	return this;
	
}
@FindBy(how=How.ID, using="buttonSearch")
private WebElement  eleClickSearchButton;

public VendorsSearchResultPage clickSearchButton() {
	click(eleClickSearchButton);
	return new VendorsSearchResultPage(driver, node, test);
	}
}
